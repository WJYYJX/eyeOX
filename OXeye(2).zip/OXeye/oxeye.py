import csv
import os
import sys

import numpy as np
from PyQt5.QtCore import Qt, QRect, QPoint
from PyQt5.QtGui import *
from PyQt5.QtWidgets import *

from calculate_oxy import calculate_oxy, read_image
from oxeye_ui import Ui_OXeye

from qframelesswindow import FramelessMainWindow

from utility import *


class OXeye(FramelessMainWindow, Ui_OXeye):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setupUi(self)

        #
        # # self.number_lable = self.label_3
        # # self.number_lable1 = self.label_4
        #
        # self.detect_image = self.label
        # self.detect_image1 = self.label_2
        #
        # # 设置路径
        # self.path = (".")
        # self.path1 = (".")
        #
        # self.img_list = os.listdir(self.path)
        # self.img_list1 = os.listdir(self.path1)
        #
        # self.comboBox.addItems([self.img_list[i] for i in range(len(self.img_list))])
        # self.comboBox.activated.connect(self.show_img)
        #
        # self.comboBox_2.addItems([self.img_list1[i] for i in range(len(self.img_list1))])
        # self.comboBox_2.activated.connect(self.show_img1)
        #
        # self.pushButton_7.clicked.connect(self.exit)
        # self.pushButton.clicked.connect(self.ecalculate)
        #
        # vbox = QVBoxLayout()
        # self.button_width = self.pushButton_3
        # vbox.addWidget(self.button_width)
        # vbox.addStretch()
        # self.button_width.clicked.connect(self.choose_width)
        #
        # self.button_color = self.pushButton_4
        # vbox.addWidget(self.button_color)
        # vbox.addStretch()
        # self.button_color.clicked.connect(self.choose_color)
        #
        # # self.button_color = self.pushButton_5
        # # vbox.addWidget(self.button_color)
        # # vbox.addStretch()
        # # self.button_color.clicked.connect(self.choose_color)
        #
        # # 选择绘画文件 按钮
        # self.button_file = self.pushButton_5
        #
        # vbox.addWidget(self.button_file)
        # vbox.addStretch()
        # self.button_file.clicked.connect(self.show_img)
        #
        # eraser = QAction(QIcon("1239616.png"), "Eraser", self)
        # eraser.setToolTip("Eraser")

        self.__setupComponents()
        self.titleBar.raise_()

    def __setupComponents(self):
        self.originFileDir = "."
        self.markFileDir = "."

        originFiles = os.listdir(self.originFileDir)
        markFiles = os.listdir(self.markFileDir)
        self.comboBox_origin.addItems(originFiles)
        self.comboBox_origin.activated.connect(self.show_origin_img)

        self.markFilePath = ""
        self.comboBox_mark.addItems(markFiles)
        self.comboBox_mark.activated.connect(self.show_mark_img)

        self.pushButton_calculate.clicked.connect(self.calculate)
        self.pushButton_exit.clicked.connect(self.exit)

        # 画笔启用画笔
        def pen_enabled(enabled):
            if enabled:
                print("pen enabled")
                self.label_mark.setCursor(Qt.CrossCursor)
            else:
                print("pen disabled")
                self.label_mark.setCursor(Qt.ArrowCursor)

        self.checkBox_pen_enabled.clicked.connect(pen_enabled)

        def pen_erase(enabled):
            if enabled and self.checkBox_pen_enabled.isChecked():
                print("pen erase enabled")
            else:
                print("pen erase disabled")

        self.checkBox_pen_erase.clicked.connect(pen_erase)
        self.drawVertex = []
        # 监听事件
        label_mark_mousePressEvent = self.label_mark.mousePressEvent

        def label_mark_mousePressEvent_wrapper(event):
            self.drawVertex.append([])
            return label_mark_mousePressEvent(event)

        self.label_mark.mousePressEvent = label_mark_mousePressEvent_wrapper

        self.label_mark.setMouseTracking(True)
        label_mark_mouseMoveEvent = self.label_mark.mouseMoveEvent

        def get_color():
            text = self.comboBox_color.currentText()
            if text == "红":
                return QColor(255, 0, 0)
            elif text == "绿":
                return QColor(0, 255, 0)
            elif text == "黄":
                return QColor(255, 255, 0)

        def label_mark_mouseMoveEvent_wrapper(event):
            if (event.buttons() == Qt.LeftButton and self.checkBox_pen_enabled.isChecked()
                    and not self.checkBox_pen_erase.isChecked()):
                self.drawVertex[len(self.drawVertex) - 1].append(
                    [event.pos(), get_color(), self.spinBox_pen_width.value()])
            elif (event.buttons() == Qt.LeftButton and self.checkBox_pen_enabled.isChecked()
                  and self.checkBox_pen_erase.isChecked()):
                self.drawVertex[len(self.drawVertex) - 1].append(
                    [event.pos(), QColor(Qt.transparent), self.spinBox_pen_width.value()])
            return label_mark_mouseMoveEvent(event)

        self.label_mark.mouseMoveEvent = label_mark_mouseMoveEvent_wrapper

        label_mark_paintEvent = self.label_mark.paintEvent

        def label_mark_paintEvent_wrapper(event):
            re = label_mark_paintEvent(event)
            pixmap = self.vertexToPixmap()
            painter = QPainter(self.label_mark)
            painter.drawImage(QRect(QPoint(0, 0), self.label_mark.size()),
                              pixmap.scaled(self.label_mark.size(), Qt.KeepAspectRatio, Qt.SmoothTransformation))
            self.label_mark.update()
            return re

        self.label_mark.paintEvent = label_mark_paintEvent_wrapper

        # 保存标注
        self.pushButton_pen_save.clicked.connect(self.saveDrawImage)

        # 清除
        self.pushButton_pen_clear.clicked.connect(self.drawVertex.clear)

    def show_origin_img(self):
        imgPath = self.comboBox_origin.currentText()
        pix = QPixmap(os.path.join(self.originFileDir, imgPath))

        if pix.isNull():
            Message.showError(self, "错误", "图片加载失败！")
            return

        self.label_origin.setPixmap(pix.scaled(self.label_origin.size(), Qt.KeepAspectRatio, Qt.SmoothTransformation))
        self.groupBox_origin.setTitle(f"原始图：{imgPath}")

    def show_mark_img(self):
        imgPath = self.comboBox_mark.currentText()
        self.markFilePath = os.path.join(self.markFileDir, imgPath)
        pix = QPixmap(self.markFilePath)

        if pix.isNull():
            Message.showError(self, "错误", "图片加载失败！")
            return

        self.label_mark.setPixmap(pix.scaled(self.label_mark.size(), Qt.KeepAspectRatio, Qt.SmoothTransformation))
        self.groupBox_mark.setTitle(f"标注图：{imgPath}")

    def choose_width(self):
        width, ok = QInputDialog.getInt(self, '选择画笔粗细', '请输入粗细：', min=1, step=1)
        if ok:
            self.lb.penwidth = width

    def choose_color(self):
        color = QColorDialog.getColor()
        if color.isValid():
            self.lineEdit_color.setText(color.name())

    def erase(self):
        self.lb.Color = Qt.white
        self.lb.setCursor(Qt.CrossCursor)
        self.lb.penwidth = self.lb.penwidth + 2

    def calculate(self):
        originPath = self.comboBox_origin.currentText()
        markPath = self.comboBox_mark.currentText()

        cwd = os.getcwd()

        img2 = self.comboBox.currentText()
        img1 = 'D:/OXeye/{name}'.format(name=img2)
        filename = os.path.splitext(img2)[0]
        mask2 = self.comboBox_2.currentText()
        mask1 = 'D:/OXeye/{name}'.format(name=mask2)
        file_extension = os.path.splitext(mask1)[0]
        mask = '{name}.nrrd'.format(name=file_extension)
        #
        # mask = r"D:\OXeye\OD_20230428121539.nrrd"
        img, mask = read_image(img1, mask)
        ves_info, art_info = calculate_oxy(img, mask.T)
        ves_info[0].sort(key=None, reverse=False)
        art_info[0].sort(key=None, reverse=False)
        n = len(ves_info[0])
        m = (0.05 * n) / 2
        m = int(m)
        print(ves_info[0][m:n - m])
        print(art_info[0][m:n - m])
        ves = np.mean(ves_info[0][10:n - 10])
        art = np.mean(art_info[0][10:n - 10])
        list1 = [filename, ves, art]
        # import matplotlib.pyplot as plt
        # plt.figure()
        # bins = np.linspace(-5, 5, 100)
        # plt.hist(ves_info[0], bins, alpha=0.5)
        # plt.hist(art_info[0], bins, alpha=0.5)
        # plt.show()

        with open("file.csv", "a", encoding="utf-8", newline="") as f:
            # 2. 基于文件对象构建 csv写入对象
            csv_writer = csv.writer(f)
            # 3. 构建列表头
            name = ['ID', '静脉血氧', '动脉血氧']
            csv_writer.writerow(name)
            # 4. 写入csv文件内容

            csv_writer.writerow(list1)
            print("写入数据成功")
            # 5. 关闭文件
            f.close()

    def openfile(self):
        fname = QFileDialog.getOpenFileName(self, "选择图片文件", ".")
        if fname[0]:
            self.lb.pixmap = QPixmap(fname[0])

    @staticmethod
    def exit():
        QApplication.instance().quit()

    def vertexToPixmap(self):
        pixmap = QImage(self.label_mark.size(), QImage.Format_ARGB32)
        pixmap.fill(Qt.transparent)
        painter = QPainter(pixmap)
        for vertex in self.drawVertex:
            for i in range(len(vertex) - 1):
                if vertex[i][1].alpha() == 0:
                    painter.setCompositionMode(QPainter.CompositionMode_Clear)
                else:
                    painter.setCompositionMode(QPainter.CompositionMode_SourceOver)
                painter.setPen(QPen(vertex[i][1], vertex[i][2], Qt.SolidLine))
                painter.drawLine(vertex[i][0], vertex[i + 1][0])
        return pixmap

    def saveDrawImage(self):
        # 选择保存位置
        savePath = QFileDialog.getSaveFileName(self, "保存标注", ".", "NRRD (*.nrrd)")
        if savePath[0] == "":
            return
        # pixmap_to_nrrd(self.vertexToPixmap(), savePath[0])

        # 获得原图片大小
        mark_pixmap = QPixmap(self.markFilePath)
        mark_pixmap_size = mark_pixmap.size()

        p1 = self.vertexToPixmap().scaled(mark_pixmap_size, Qt.KeepAspectRatioByExpanding, Qt.SmoothTransformation)
        p2 = mark_pixmap

        p1_center = QPoint(p1.width() // 2, p1.height() // 2)
        p2_center = QPoint(p2.width() // 2, p2.height() // 2)
        offset = p1_center - p2_center
        rect = QRect(offset, p2.size())
        result = p1.copy(rect)

        convert_qimage_to_nrrd(result, savePath[0])
