import cv2
from PyQt5.QtCore import Qt
from PyQt5.QtWidgets import QMessageBox, QWidget
from PyQt5.QtGui import QPixmap, QImage
import nrrd
import numpy as np

import matplotlib.pyplot as plt


def qimage_to_numpy(qimage):
    """Convert a QImage to a NumPy array."""
    qimage: QImage = qimage.convertToFormat(QImage.Format_RGB888)
    qimage.save("temp.jpg")
    img = cv2.imread("temp.jpg")
    mirrored_image = cv2.transpose(img)
    # 转为灰度图
    # mirrored_image = cv2.cvtColor(mirrored_image, cv2.COLOR_RGB2GRAY)
    return mirrored_image


def convert_qimage_to_nrrd(qimage, output_path):
    # Convert QImage to NumPy array
    image_array = qimage_to_numpy(qimage)

    # 三通道合一
    image_array = image_array[:, :, 0] + image_array[:, :, 1] + image_array[:, :, 2]

    # 限制最大值
    image_array[image_array > 255] = 255

    data = image_array
    print(data.shape)

    # Create NRRD header
    header = {
        'dimension': 2,
        'sizes': data.shape,
        'type': 'uchar',  # 数据类型，可以根据实际情况修改
    }

    # Save the data to the NRRD file
    nrrd.write(output_path, data, header)


class Message:
    @staticmethod
    def showInfo(parent: QWidget, title: str, message: str):
        msg = QMessageBox(parent)
        msg.setWindowTitle(title)
        msg.setText(message)
        msg.setIcon(QMessageBox.Icon.Information)

        msg.exec()
        return msg

    @staticmethod
    def showWarning(parent: QWidget, title: str, message: str):
        msg = QMessageBox(parent)
        msg.setWindowTitle(title)
        msg.setText(message)
        msg.setIcon(QMessageBox.Icon.Warning)

        msg.exec()
        return msg

    @staticmethod
    def showError(parent: QWidget, title: str, message: str):
        msg = QMessageBox(parent)
        msg.setWindowTitle(title)
        msg.setText(message)
        msg.setIcon(QMessageBox.Icon.Critical)

        msg.exec()
        return msg

    @staticmethod
    def showAsk(parent: QWidget, title: str, message: str) -> bool:
        msg = QMessageBox(parent)
        msg.setWindowTitle(title)
        msg.setText(message)
        msg.setIcon(QMessageBox.Icon.Question)
        msg.setStandardButtons(QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No)
        return msg.exec() == QMessageBox.StandardButton.Yes
