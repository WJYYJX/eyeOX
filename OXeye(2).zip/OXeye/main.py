from PyQt5.QtWidgets import QApplication
from PyQt5.QtCore import Qt
from oxeye import OXeye
import qdarkstyle
from qdarkstyle.light.palette import LightPalette

QApplication.setAttribute(Qt.AA_EnableHighDpiScaling)
QApplication.setHighDpiScaleFactorRoundingPolicy(Qt.HighDpiScaleFactorRoundingPolicy.PassThrough)


def main():
    app = QApplication([])
    app.setStyleSheet(qdarkstyle.load_stylesheet(qt_api='pyqt5', palette=LightPalette()))
    w = OXeye()
    w.show()
    app.exec_()


if __name__ == "__main__":
    main()
