import numpy as np
import nrrd

# 生成一些示例数据
data = np.random.rand(512, 512)  # 二维数据，可以根据需要修改维度和大小

# 定义头部信息
header = {
    'dimension': 2,
    'sizes': data.shape,
    'type': 'float',  # 数据类型，可以根据实际情况修改
}

# 指定文件名
file_name = 'output.nrrd'

# 写入NRRD文件
nrrd.write(file_name, data, header)
